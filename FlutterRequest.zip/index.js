const axios = require('axios');

module.exports = async function (context, req) {
    const tokenUrl = 'https://login.microsoftonline.com/077a2c83-2d96-4b51-b5f8-ce432e8508e1/oauth2/v2.0/token';

    const data = new URLSearchParams({
        grant_type: 'client_credentials',
        client_id: '18607520-d169-4cf0-bc79-a0d23ab121ec',
        client_secret: 'yOr8Q~xp8tw3bH-WzZEPiSI..~4SIdCOaLATUbXe',
        scope: 'https://pitcrmsandbox.api.crm4.dynamics.com/.default'
    });

    try {
        const response = await axios.post(tokenUrl, data.toString(), {
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' }
        });

        if (response.status === 200 && response.data.access_token) {
            context.res = {
                status: 200,
                body: {
                    access_token: response.data.access_token
                }
            };
        } else {
            context.res = {
                status: 400,
                body: {
                    error: 'Failed to retrieve token.',
                    details: response.data
                }
            };
        }
    } catch (error) {
        context.res = {
            status: 500,
            body: {
                error: 'Request failed',
                details: error.message
            }
        };
    }
};
